user_ch=int(input("enter the choice: 0 for rock 1 for paper 2 for scissors"))
if user_ch >=3 or user_ch <=0:
 print("invalid number entered")
else:
    import random
    computer_ch=random.randint(0,2)
    print("computer choose:")
    print(computer_ch)
    if computer_ch == user_ch:
       print("its a tie")
    elif computer_ch ==0 and user_ch == 2:
       print("you loose")
    elif user_ch ==0 and computer_ch == 2 :
       print("you win")
    elif computer_ch > user_ch:
       print("you lose")
    elif user_ch > computer_ch:
       print("you win")